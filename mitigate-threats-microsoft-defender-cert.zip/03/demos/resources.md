# Mitigate threats using Azure Defender

## Module 2: Design and configure Azure Defender Implementation

- [Introduction to Azure Defender](https://docs.microsoft.com/en-us/azure/security-center/azure-defender)
- [Understanding Azure Security Center](https://docs.microsoft.com/en-us/learn/modules/what-is-azure-defender/3-understand-azure-secure-center)
- [Continuously export ASC](https://docs.microsoft.com/en-us/azure/security-center/continuous-export?tabs=azure-portal)
- [Data retention policies](https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/data-retention-settings?view=o365-worldwide#update-data-retention-settings)
- [How long will Microsoft store my Data? What is MS data retention policy?](https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/data-storage-privacy?view=o365-worldwide#how-long-will-microsoft-store-my-data-what-is-microsofts-data-retention-policy)
- [Manage usage and costs with Azure Monitor Logs](https://docs.microsoft.com/en-us/azure/azure-monitor/logs/manage-cost-storage#change-the-data-retention-period)
- [Microsoft Defender Security Center operations dashboard](https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/security-operations-dashboard?view=o365-worldwide)
- [Permissions in Azure Security Center](https://docs.microsoft.com/en-us/azure/security-center/security-center-permissions)
- [Verify data storage location and update data retention settings for Microsoft Defender for Endpoint](https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/data-retention-settings?view=o365-worldwide#update-data-retention-settings)

## Module 3: Implement the use of data connectors in Azure Defender
- [Connect AWS Account to ASC](https://docs.microsoft.com/en-us/azure/security-center/quickstart-onboard-aws?WT.mc_id=Portal-Microsoft_Azure_Security)
- [Configure autoprovisioning for agents and extensions from ASC](https://docs.microsoft.com/en-us/azure/security-center/security-center-enable-data-collection?WT.mc_id=Portal-Microsoft_Azure_Security)
- [Log Analytics VM extension for Windows](https://docs.microsoft.com/en-us/azure/virtual-machines/extensions/oms-windows?toc=/azure/azure-monitor/toc.json#powershell-deployment)
- [Log Analytics VM extension for Linux](https://docs.microsoft.com/en-us/azure/virtual-machines/extensions/oms-linux?toc=/azure/azure-monitor/toc.json)
- [Connect non-Azure Machines](https://docs.microsoft.com/en-us/learn/modules/connect-non-azure-machines-to-azure-defender/3-connect-non-azure-machines)
- [Enable auto provisioning of the Log Analytics agent and extensions](https://docs.microsoft.com/en-us/azure/security-center/security-center-enable-data-collection)
## Module 4: Manage Azure Defender alert rules
- [Configure Email notifications for Security Alerts](https://docs.microsoft.com/en-us/azure/security-center/security-center-provide-security-contact-details)
- [Security Contacts API Info](https://docs.microsoft.com/en-us/rest/api/securitycenter/security-contacts)
- [Suppress alerts from Azure Defender](https://docs.microsoft.com/en-us/azure/security-center/alerts-suppression-rules)
- [Alert Validation in ASC](https://docs.microsoft.com/en-us/azure/security-center/alerts-suppression-rules)
- [Validate Alert Configurations](https://docs.microsoft.com/en-us/azure/security-center/security-center-alert-validation)
## Module 5: Investigate Azure Defender alerts and incidents 
- [Security Alerts and Incidents in ASC](https://docs.microsoft.com/en-us/azure/security-center/security-center-alerts-overview#continuous-monitoring-and-assessments)
- [Security Alerts-a reference guide](https://docs.microsoft.com/en-us/azure/security-center/alerts-reference)
- [MITRE ATT&CK tactics](https://docs.microsoft.com/en-us/azure/security-center/alerts-reference?WT.mc_id=Portal-Microsoft_Azure_Security_AzureDefenderForData#intentions)
- [MITRE ATT&CK Enterprise Matrix](https://attack.mitre.org/versions/v7/matrices/enterprise/)
- [Microsoft Defender for Clouds enhanced security features](https://docs.microsoft.com/en-us/azure/security-center/enhanced-security-features-overview?WT.mc_id=Portal-Microsoft_Azure_Security)
- [Azure Threat Protection](https://docs.microsoft.com/en-us/azure/security/fundamentals/threat-detection#threat-intelligence)
- [Respond to Azure Defender for Key Vault Alerts](https://docs.microsoft.com/en-us/azure/security-center/defender-for-key-vault-usage)
## Module 6: Configure automation and remediation
- [Overview of automated investigations](https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/automated-investigations?view=o365-worldwide)
- [Use an alert to trigger and Azure automation runbook](https://docs.microsoft.com/en-us/azure/automation/automation-create-alert-triggered-runbook)
- [Microsoft.Security automations](https://docs.microsoft.com/en-us/azure/templates/microsoft.security/automations?tabs=bicep)
- [Track and respond to emerging threats through threat analytics](https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/threat-analytics?view=o365-worldwide)

### Module 7

- [Microsoft Certified: Security Operations Analyst Associate](https://docs.microsoft.com/en-us/learn/certifications/security-operations-analyst/)
- [Exam: SC-200: Microsoft Security Operations Analyst](https://docs.microsoft.com/en-us/learn/certifications/exams/sc-200)

```Powershell
#use this command when you need to create a new resource group for your deployment
New-AzResourceGroup -Name <resource-group-name> -Location <resource-group-location> 

New-AzResourceGroupDeployment -ResourceGroupName <resource-group-name> -TemplateUri https://raw.githubusercontent.com/Azure/azure-quickstart-templates/master/quickstarts/microsoft.security/securitycenter-create-automation-for-alertnamecontains/azuredeploy.json

Get-AzSecurityAlert | Where-object {$_.AlertDisplayName -like "*SQL*"} | select AlertDisplayName, severity
### Teske Contact

- [LinkedIn](https://www.linkedin.com/in/michael-teske-45240561/)



